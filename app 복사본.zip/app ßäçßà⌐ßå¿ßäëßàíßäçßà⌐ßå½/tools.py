from app.crawler import crawl_naver_news
from app.vector_search import store_news_to_pinecone, query_news_from_pinecone

def extract_keywords(state):
    query = state["query"]
    keywords = [kw.strip() for kw in query.lower().split() if len(kw) > 1]
    state["keywords"] = keywords
    return state

def search_news(state):
    keywords = state.get("keywords", [])
    keyword_str = " ".join(keywords)
    articles = crawl_naver_news(keyword_str, 5)
    store_news_to_pinecone(articles)  # 벡터 DB에 저장
    search_results = query_news_from_pinecone(keyword_str, top_k=3)

    state["news_results"] = [
        {
            "title": doc.metadata.get("title"),
            "url": doc.metadata.get("url"),
            "content": doc.page_content
        } for doc in search_results
    ]
    return state

def summarize_news(state):
    articles = state.get("news_results", [])
    summary = "\n".join([f"요약: {a['title']} - {a['content'][:50]}..." for a in articles])
    state["summary"] = summary
    return state
