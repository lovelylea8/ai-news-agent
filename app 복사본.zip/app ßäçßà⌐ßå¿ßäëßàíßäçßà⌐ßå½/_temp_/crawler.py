import requests
from bs4 import BeautifulSoup

def crawl_naver_news(keyword, num_news_data):
    news_data = []
    start = 1
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    while len(news_data) < num_news_data:
        url = f"https://search.naver.com/search.naver?where=news&query={keyword}&start={start}"
        print(f"URL 요청: {url}")
        
        response = requests.get(url, headers=headers)
        print(f"응답 상태 코드: {response.status_code}")


        soup = BeautifulSoup(response.text, 'html.parser')
        news_items = soup.select("div.news_area")

        for item in news_items:
            if len(news_data) >= num_news_data:
                break
            title_tag = item.select_one("a.news_tit")
            title = title_tag.get('title') if title_tag else "제목 없음"
            content_tag = item.select_one("div.dsc_wrap")
            content = content_tag.text.strip() if content_tag else "내용 없음"
            news_url = title_tag.get('href') if title_tag else None
            news_data.append({
                "title": title,
                "content": content,
                "url": news_url
            })

        start += 10
        if not news_items:
            break

        print(f"뉴스 항목 개수: {len(news_items)}")

    return news_data


if __name__ == "__main__":
    keyword = "인공지능"
    news = crawl_naver_news(keyword, 5)
    print(f"📰 크롤링된 뉴스 개수: {len(news)}")
    for i, article in enumerate(news, 1):
        print(f"[{i}] {article['title']}")
        print(f"URL: {article['url']}")
        print(f"내용: {article['content'][:50]}...")
        print("-" * 40)
