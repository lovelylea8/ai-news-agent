from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.graph_workflow import create_workflow
from typing import Dict, List, Any
import logging

agent_app = FastAPI()

# 입력 모델 정의
class QueryInput(BaseModel):
    query: str

# 워크플로우 초기화
graph = create_workflow()

@agent_app.post("/agent")
async def run_agent(input: QueryInput) -> Dict[str, Any]:
    """사용자 쿼리로 워크플로우 실행, 결과 반환"""
    logging.info(f"받은 쿼리: '{input.query}'")
    try:
        # 상태 초기화
        state = {
            "query": input.query,
            "keywords": [],
            "news_results": [],
            "summary": "",
            "error": ""
        }
        result = await graph.ainvoke(state)  # 비동기 실행
        if result.get("error"):
            raise HTTPException(status_code=400, detail=result["error"])
        return {
            "summary": result.get("summary", "요약 실패"),
            "keywords": result.get("keywords", []),
            "news_results": result.get("news_results", [])
        }
    except Exception as e:
        logging.error(f"워크플로우 실행 실패: {e}")
        raise HTTPException(status_code=500, detail=f"처리 중 오류: {str(e)}")